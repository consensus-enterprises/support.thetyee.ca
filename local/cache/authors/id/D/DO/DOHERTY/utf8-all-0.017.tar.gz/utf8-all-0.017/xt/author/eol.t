use strict;
use warnings;

# this test was generated with Dist::Zilla::Plugin::Test::EOL 0.18

use Test::More 0.88;
use Test::EOL;

my @files = (
    'lib/utf8/all.pm',
    't/00-compile.t',
    't/ARGV.t',
    't/ARGV_nonmain.t',
    't/ARGV_twice.t',
    't/FATAL_utf8.t',
    't/autodie.t',
    't/charnames.t',
    't/fc.t',
    't/glob.t',
    't/lexical-again.t',
    't/lexical.t',
    't/open.t',
    't/readdir.t',
    't/readlink.t',
    't/readpipe.t',
    't/unicode_eval.t',
    't/unicode_strings.t',
    't/utf8.t'
);

eol_unix_ok($_, { trailing_whitespace => 1 }) foreach @files;
done_testing;
